import torch
import geotorch.parametrize as P


from .skew import Skew

from .stiefel import Stiefel



def _register_manifold(module, tensor_name, cls, *args):
    tensor = getattr(module, tensor_name)
    M = cls(tensor.size(), *args).to(device=tensor.device, dtype=tensor.dtype)

    # Initialize without checking in manifold
    X = M.sample()
    if not P.is_parametrized(module, tensor_name):
        with torch.no_grad():
            tensor.copy_(X)
    else:
        setattr(module, tensor_name, X)

    P.register_parametrization(module, tensor_name, M, unsafe=True)

    return module

def skew(module, tensor_name="weight", lower=True):
    r"""Adds a skew-symmetric parametrization to the matrix ``module.tensor_name``.

    When accessing ``module.tensor_name``, the module will return the parametrized
    version :math:`X` so that :math:`X^\intercal = -X`.

    If the tensor has more than two dimensions, the parametrization will be
    applied to the last two dimensions.

    Examples::

        >>> layer = nn.Linear(30, 30)
        >>> geotorch.skew(layer, "weight")
        >>> torch.allclose(layer.weight, -layer.weight.T)
        True

    Args:
        module (nn.Module): module on which to register the parametrization
        tensor_name (string): name of the parameter, buffer, or parametrization
            on which the parametrization will be applied. Default: ``"weight"``
        lower (bool): Optional. Uses the lower triangular part of the matrix to
            parametrize the matrix. Default: ``True``
    """
    P.register_parametrization(module, tensor_name, Skew(lower))
    return module

def orthogonal(module, tensor_name="weight", triv="expm"):
    r"""Adds an orthogonal parametrization to the tensor ``module.tensor_name``.

    When accessing ``module.tensor_name``, the module will return the
    parametrized version :math:`X` so that :math:`X^\intercal X = \operatorname{I}`.

    If the tensor has more than two dimensions, the parametrization will be
    applied to the last two dimensions.

    Examples::

        >>> layer = nn.Linear(20, 30)
        >>> geotorch.orthogonal(layer, "weight")
        >>> torch.norm(layer.weight.T @ layer.weight - torch.eye(20,20))
        tensor(4.8488e-05)

        >>> layer = nn.Conv2d(20, 40, 3, 3)  # Make the kernels orthogonal
        >>> geotorch.orthogonal(layer, "weight")
        >>> torch.norm(layer.weight.transpose(-2, -1) @ layer.weight - torch.eye(3,3))
        tensor(1.2225e-05)

    Args:
        module (nn.Module): module on which to register the parametrization
        tensor_name (string): name of the parameter, buffer, or parametrization
            on which the parametrization will be applied. Default: ``"weight"``
        triv (str or callable): Optional.
            A map that maps a skew-symmetric matrix to an orthogonal matrix.
            It can be the exponential of matrices or the cayley transform passing
            ``["expm", "cayley"]`` or a custom callable.  Default: ``"expm"``
    """
    return _register_manifold(module, tensor_name, Stiefel, triv)



